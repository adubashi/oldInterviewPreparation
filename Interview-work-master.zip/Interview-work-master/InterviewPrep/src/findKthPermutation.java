
import java.util.*;

public class findKthPermutation {

	public static void main(String[] args) {
		List<Character> v = new ArrayList<Character>();
		v.add('t');
		v.add('d');
		v.add('s');
		
		StringBuilder s = new StringBuilder();
		int k = 6;
		findNthPermutation(v,k,s);
		
		System.out.println(s);
		
		
	}
	
	public static int factorial(int n){
		if (n == 0 || n == 1) return 1;
		return n * factorial(n - 1);
	}
	
	public static void findNthPermutation(
			List<Character> v,
			int k,
			StringBuilder result)
	{
		if(v.isEmpty()){
			return;
		}
		int n = v.size();
		int count = factorial(n-1);
		int selected = (k - 1)/count;
		
		result.append(v.get(selected));
		v.remove(selected);
		
		k = k - (count *selected);
		
		findNthPermutation(v,k,result);
	}

}
