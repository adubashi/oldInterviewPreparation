import java.util.*;




public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char[] just = {'a','b','c','d',' ',' ',' ','e'};
		
		System.out.println(Arrays.toString(just));
		
		removeWhiteSpace(just);
		
		System.out.println(Arrays.toString(just));
	}
	
	public static boolean isSpace(char c){
		
		return c == ' ';
	}
	
	public static void removeWhiteSpace(char[] s){
		if(s == null || s.length == 0 || s[0] == '\0'){
			return;
		}
		int read_ptr = 0;
		int write_ptr = 0;
		
		while(read_ptr < s.length && s[read_ptr] != '\0'){
			if(!isSpace(s[read_ptr])){
				s[write_ptr] = s[read_ptr];
				++write_ptr;
			}
			++read_ptr;
		}
		
		s[write_ptr] = '\0';
	}

}
