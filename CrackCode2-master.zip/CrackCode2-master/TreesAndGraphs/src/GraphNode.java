import java.util.*;
public class GraphNode {
	private char NodeLabel;
	private int NodeID;
	
	public Vector<GraphNode> links;
	
	
	public GraphNode(char NodeLabel, int NodeID){
		this.NodeLabel = NodeLabel;
		this.NodeID = NodeID;
		
	}
	
	

}
