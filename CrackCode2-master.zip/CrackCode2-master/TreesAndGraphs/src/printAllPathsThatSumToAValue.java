import java.util.*;

//Straight line path
public class printAllPathsThatSumToAValue {
	public static class TreeNode {
		int data;
		TreeNode left;
		TreeNode right;
	}
	
	public static void print(int[] path, int start, int end){
		for(int i = start; i <= end; i++){
			System.out.print(path[i]);
		}
		System.out.println();
	}
	
	//O(nlogn)
	public static void findSum(TreeNode node, int sum, int[] path, int level){
		if(node == null){
			return;
		}
		
		path[level] = node.data;
		int t = 0;
		for(int i =level ; i>= 0; i--){
			t += path[i];
			if(t == sum){
				print(path, i, level);
			}
		}
	}
	
	public static void findSum(TreeNode node, int sum){
		int depth = depth(node);
		int[] path = new int[depth];
		findSum(node, sum, path,0);
	}
	
	public static int depth(TreeNode node){
		if(node == null){
			return 0;
		} else {
			return 1 + Math.max(depth(node.left), depth(node.right));
		}
	}

}
