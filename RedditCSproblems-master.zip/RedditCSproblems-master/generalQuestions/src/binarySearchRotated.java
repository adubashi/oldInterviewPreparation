
public class binarySearchRotated {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static int binarySearch(
			int[] arr, 
			int st, 
			int end,
			int key)
	{
		
		if(st > end){
			return -1;
		}
		
		int mid = st + (end - st)/2;
		
		if(arr[mid] == key){
			return mid;
		}
		
		if(arr[st] < arr[mid] && key < arr[mid] && key >= arr[st]){
			return binarySearch(arr,st,mid-1,key);
		} else if(arr[mid] < arr[end] && key > arr[mid] && key <= arr[end]){
			return binarySearch(arr, mid +1, end,key);
		} else if(arr[st] > arr[mid]){
			return binarySearch(arr,st,mid-1,key);
		} else if(arr[end] < arr[mid]){
			return binarySearch(arr,mid+1,end,key);
		}
		
		
		return -1;
	}

}
