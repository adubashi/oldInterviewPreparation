import java.util.*;


public class validSumTree {

	/**
	 * @param args
	 */
	
	public static class BNode{
		int data;
		BNode left;
		BNode right;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public static boolean isLeaf(BNode root){
		return root.left == null && root.right == null;
	}

    
	//1 if true, 0 if not
	public static int isSumTree(BNode root){
		int ls= 0;
		int rs = 0;
		
		
		if(root == null || (root.left == null && root.right == null)){
			return 1;
		}
		if( isSumTree(root.left) != 0  && isSumTree(root.right) != 0 ){
			if(root.left == null){
	            ls = 0;
			}else if(isLeaf(root.left)){
				ls = root.left.data;
			}else{
				ls = 2*(root.left.data);
			}
	        // Get the sum of nodes in right subtree
			if(root.right == null){
	            ls = 0;
			}else if(isLeaf(root.right)){
				ls = root.right.data;
			}else{
				ls = 2*(root.right.data);
			}
			
		}
		
		return 0;
		
		
	}

}
