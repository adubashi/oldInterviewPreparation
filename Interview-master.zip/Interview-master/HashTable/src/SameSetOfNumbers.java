import java.util.*;
public class SameSetOfNumbers {
	
	
	public static void main(String Args[]){
		int [] a1 = {1,2,3};
		int [] a2 = {1,2,3};
		
		System.out.println(sameSetAndNumber(a1,a2));
	}
	
	
	//Checks if the numbers are made from the set same 
	public static boolean sameSet(int[] a1, int[] a2){
		boolean val = true;
		Hashtable<Integer,Integer> temp = new Hashtable<Integer,Integer>();
		for(int i : a1)
			temp.put(i,0);
		for(int i : a2)
			if(temp.containsKey(i)){
				int j = temp.get(i);
				System.out.print(i + " ");
			}else{
				val =false;
			}
		
		return  val;
				
		
	}
	
	public static boolean sameSetAndNumber(int[] a1, int[] a2){
		boolean val = true;
		Hashtable<Integer,Integer> temp = new Hashtable<Integer,Integer>();
		Hashtable<Integer,Integer> temp2 = new Hashtable<Integer,Integer>();
		for(int i : a1)
			temp.put(i,0);
		for(int i : a2)
			temp2.put(i, 0);
		return  temp.equals(temp2);
				
		
	}

}
