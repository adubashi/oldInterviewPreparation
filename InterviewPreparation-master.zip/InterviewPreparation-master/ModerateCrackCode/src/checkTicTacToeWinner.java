
public class checkTicTacToeWinner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static int convertBoardToInt(char[][] board){
		int factor = 1;
		int sum = 0;
		for(int i = 0; i < board.length; i++){
			for(int j = 0; i < board[i].length; j++){
				int v= 0;
				if(board[i][j] == 'x'){
					v = 1;
				} else if(board[i][j] == 'o'){
					v = 2;
				} 
				sum += v * factor;
				factor *= 3;
			}
		}
		return sum;
	}
	
	//For 3 by 3
	public static char hasWon1(char[][] board){
		for(int i = 0; i < board.length; i++){
			//Check rows
			if(board[i][0] != ' ' &&
			   board[i][0] == board[i][1] &&
			   board[i][0] == board[i][2]){
				return board[i][0];
			}
			//Check columns
			if(board[0][i] != ' ' &&
			   board[0][i] == board[1][i] &&
			   board[0][i] == board[2][i]){
						return board[0][i];
			}
			
			//Check diagonal
			if(board[0][0] != ' ' &&
			   board[0][0] == board[1][1] &&
			   board[0][0] == board[2][2]){
						return board[0][0];
			}
			//Check diagonal
			if(board[0][0] != ' ' &&
			   board[0][0] == board[1][1] &&
			   board[0][0] == board[2][2]){
						return board[0][0];
			}
		}
		return ' ';
	}

}
