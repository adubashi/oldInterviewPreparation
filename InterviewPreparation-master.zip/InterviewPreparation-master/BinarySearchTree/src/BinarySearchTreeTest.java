
public class BinarySearchTreeTest {

	public static void main(String[] args) {
		BST b1 = new BST();
		
		b1.insert(4);
		b1.insert(5);
		b1.insert(10);
		b1.insert(-1);
		
		b1.inorder();

	}

}
