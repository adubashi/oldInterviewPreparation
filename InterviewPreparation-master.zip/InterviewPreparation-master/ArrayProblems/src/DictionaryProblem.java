
public class DictionaryProblem {
	
	public static int[] findPrimeNumbers(int start, int end){
		
	}
	
	public static int getHashCode(String str){
	     int hash = 31;
	     for(int i = 0; i < str.length(); i++){
	        //hash = hash*primes['a' - str.charAt[i]];
	     }
	     return hash;
	}
	
	

}
