
public class TreeNode {
	int data;
	TreeNode left;
	TreeNode right;

}
