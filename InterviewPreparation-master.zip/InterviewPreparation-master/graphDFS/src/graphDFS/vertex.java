package graphDFS;

public class vertex {
	public char label;
	public boolean visited;
	public vertex(char lab){
		label = lab;
		visited = false;
	}

}
