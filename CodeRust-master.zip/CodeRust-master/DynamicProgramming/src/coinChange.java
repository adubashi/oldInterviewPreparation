
public class coinChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static int solveCoinChange(int[] denominations, int amount){
		int[] solution = new int[amount + 1];
		
		solution[0] = 1;
		
		for(int den: denominations){
			for(int i = den; i < (amount + 1); i++){
				solution[i] += solution[i - den];
			}
		}
		
		return solution[solution.length - 1];
	}

}
